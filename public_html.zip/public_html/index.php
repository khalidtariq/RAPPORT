
                    <!DOCTYPE html>
  <html>
        <head>
               <meta charset="utf-8" />
               <link rel="stylesheet" href="styleMen.css" />
               <title>ropachic</title>
        </head>
    
      <body style="background-color: #F8F8FF; position:absolute">
    
          <header id="bloc_page">
  
                <div id="titre_principal" >

                    <div id="logo">
                       
                        <img src="images/zozor_logo.png" alt="Logo de Zozor" />
                                                                                <h1>Zoropa</h1>   
                    </div>
                                              &nbsp;&nbsp; &nbsp;&nbsp;<br/><h1><b><i>Meilleur Shopping</i></b></h1>
  
                </div>
  
                    <nav>
                             
                        <div class="w3-content w3-section" >
                       
                          <img class="mySlides" src="images/5.jpg">
                          <img class="mySlides" src="images/3.jpg" >
  
                         <img class="mySlides" src="images/16.jpg" >
                         <img class="mySlides" src="images/24.png">
                         <img class="mySlides" src="images/17.jpg" >
                       
                        </div>
                                <ul> 
                         
                         <li><a href="#">Accueil</a></li>
                                     <li><a href="men.php">Homme</a></li>
                                     <li><a href="femme.php">Femme</a></li>
                                     <li><a href="contact.php">Conntact</a></li>
                                      <li> <a href="login.php" style=" color: red ">Me connecter</a> </li>
                                      <li><a href="telechargement.php">À PROPOS</a></li>

                                </ul> 
                  </nav>
          </header>
           
  
                    <div>
                          
                          &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;

                          <div class="row">
                                <div class="column1">
  
                                    <div class="container">
                                          <img src="images/14.jpg" alt="Avatar" class="image">
                                               <div class="overlay">
                                                      <div class="text">Prix: 30$ <br>
                                                                        Taille:XL/M/S<br> 
                                                                        Solde: 20%
                                                                                         <a href="men.php"><button class="btn-info button1">See More</button></a>

                                                      </div>
                                                </div>
                                     </div> 
                                </div>

                          <div class="row">
                                <div class="column1">
  
                                    <div class="container">
                                          <img src="images/2.jpg" alt="Avatar" class="image">
                                                <div class="overlay">
                                                      <div class="text">Prix: 30$ <br>
                                                                        Taille:XL/M/S<br> 
                                                                        Solde: 20%
                                                                                         <a href="men.php"><button class="btn-info button1">See More </button></a>

                                                      </div>
                                                </div>
                                    </div> 
                                </div>

                          <div class="row">
                                <div class="column1">
  
                                     <div class="container">
                                          <img src="images/15.jpg" alt="Avatar" class="image">
                                                 <div class="overlay">
                                                        <div class="text">Prix: 30$ <br>
                                                                          Taille:XL/M/S<br> 
                                                                          Solde: 20%
                                                                                         <a href="men.php"><button class="btn-info button1">See More</button></a>

                                                         </div>
                                                  </div>
                                     </div> 
                                </div>
                          <div class="row">
                                <div class="column1">
  
                                     <div class="container">
                                          <img src="images/16.jpg" alt="Avatar" class="image">
                                                 <div class="overlay">
                                                        <div class="text">Prix: 30$ <br>
                                                                          Taille:XL/M/S<br> 
                                                                          Solde: 20%
                                                                                        <a href="femme.php"><button class="btn-info button1">See More</button></a>
                                                        </div>
                                                 </div>
                                     </div> 
                                </div>

                          <div class="row">
                                <div class="column1">
  
                                     <div class="container">
                                           <img src="images/18.jpg" alt="Avatar" class="image">
                                                   <div class="overlay">
                                                         <div class="text">Prix: 30$ <br>
                                                                           Taille:XL/M/S<br> 
                                                                           Solde: 20%
                                                                                        <a href="femme.php"><button class="btn-info button1">See More</button></a>

                                                          </div>
                                                    </div>
                                     </div> 
                                </div>

                          <div class="row">
                                <div class="column1">
  
                                      <div class="container">
                                           <img src="images/25.jpg" alt="Avatar" class="image" style="height: 500px ; width:  340px">
                                                 <div class="overlay">
                                                          <div class="text">Prix: 30$ <br>
                                                                            Taille:XL/M/S<br> 
                                                                            Solde: 20%
                                                                                         <a href="femme.php"><button class="btn-info button1">See More</button></a>

                                                          </div>
                                                  </div>
                                      </div> 
                                </div>
  
                          <div class="row">
                                <div class="column1">
  
                                      <div class="container">
                                            <img src="images/14.jpg" alt="Avatar" class="image">
                                                  <div class="overlay">
                                                         <div class="text">Prix: 30$ <br>
                                                                           Taille:XL/M/S<br> 
                                                                           Solde: 20%
                                                                                            <a href="men.php"><button class="btn-info button1">See More</button></a>

                                                          </div>
                                                  </div> 
                                      </div>
                                </div>

                                 <div class="column1">
                                                                     <h1 ><div class="tnd" >Tendance</div></h1>

                                      <div class="container">
                                           <img src="images/20.webp" alt="Avatar" class="image" >
                                                  <div class="overlay">
                                                         <div class="text">Prix: 30$ <br>
                                                                           Taille:XL/M/S<br> 
                                                                           Solde: 20%
                                                                                          <a href="femme.php"><button class="btn-info button1">See More</button></a>

                                                          </div>
                                                  </div>
                                      </div> 
                                  </div>
      
   


                    <div class="row">
                               <div class="column1">
  
                                     <div class="container">
                                           <img src="images/30.jpg" alt="Avatar" class="image">
                                                  <div class="overlay">
                                                          <div class="text">Prix: 30$ <br>
                                                                            Taille:XL/M/S<br> 
                                                                            Solde: 20%
                                                                                            <a href="men.php"><button class="btn-info button1">See More</button></a>

                                                          </div>
                                                  </div>
                                      </div> 
                                </div>


            <section style="background-color: #F8F8FF">
                <aside  class="vet" style="height: 1080px">
                    <h1>Vêtements</h1>
                    <img src="images/bulle.png" alt="" id="fleche_bulle" />
                    <p id="photo_zozor">    <img src="images/zozor_logo.png" alt="Logo de Zozor" /></p>
                    <p style="line-height: 320%"><b><i>Découvrez les collections des plus grands créateurs et couturiers de mode . Robes, chemises, jupes, maillots de bain, tuniques, pantalons, débardeurs ou vestes, notre large sélection de vêtements designés, créés et fabriqués à la main en Afrique, vous séduira pour toutes vos occasions. En quelques clics, accédez à l'univers des meilleures marques du continent et à une sélection de choix sur Made-in.africa !</b></p>
                   
                    <p ><a href="https://www.facebook.com" target="_blank" ><img src="images/facebook.png" alt="Facebook"  /></a>
                        
                     <a href="https://twitter.com/login?lang=ar" target="_blank"><img src="images/twitter.png" alt="Twitter" /></a> 
                     <a href="https://www.flickr.com/" target="_blank">  <img src="images/flickr.png" alt="Flickr" /></a>  
                     <a href="https://rss.com/" target="_blank"><img src="images/rss.png" alt="RSS" /></a>
                     </p>
                
                 </aside>
            </section>

         
         </div>
                     <script>
                             var myIndex = 0;
                             carousel();

                             function carousel() {
                                                  var i;
                                                  var x = document.getElementsByClassName("mySlides");
                                                  for (i = 0; i < x.length; i++) {
                                                                                  x[i].style.display = "none";  
                                                                                  }
                                                             myIndex++;
                                                         if (myIndex > x.length) {myIndex = 1}    
                                                           x[myIndex-1].style.display = "block";  
                                                          setTimeout(carousel, 2000); // Change image every 2 seconds
                                                 }
                    </script>
    </body>
</html>
